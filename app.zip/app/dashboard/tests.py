from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse


class ProtectedPageTests(TestCase):
    def test_home_is_public_and_shows_guest_actions(self):
        response = self.client.get(reverse("home"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, reverse("login"))
        self.assertContains(response, reverse("register"))

    def test_anonymous_dashboard_access_redirects_to_login(self):
        response = self.client.get(reverse("dashboard"))
        expected = f"{reverse('login')}?next={reverse('dashboard')}"

        self.assertRedirects(response, expected)

    def test_authenticated_user_can_open_home_and_dashboard(self):
        user = get_user_model().objects.create_user(
            username="printflowuser",
            password="PrintFlow!2026Demo",
        )
        self.client.force_login(user)

        home_response = self.client.get(reverse("home"))
        dashboard_response = self.client.get(reverse("dashboard"))

        self.assertEqual(home_response.status_code, 200)
        self.assertContains(home_response, reverse("dashboard"))
        self.assertContains(home_response, "Hello, printflowuser")
        self.assertEqual(dashboard_response.status_code, 200)
        self.assertContains(dashboard_response, reverse("home"))
