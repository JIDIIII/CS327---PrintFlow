from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse


class AccountFlowTests(TestCase):
    registration_data = {
        "first_name": "Alex",
        "last_name": "Printer",
        "username": "alexprinter",
        "email": "alex@example.com",
        "password1": "PrintFlow!2026Demo",
        "password2": "PrintFlow!2026Demo",
    }

    def test_login_and_register_pages_render(self):
        self.assertEqual(self.client.get(reverse("login")).status_code, 200)
        self.assertEqual(self.client.get(reverse("register")).status_code, 200)

    def test_registration_creates_hashed_user_then_redirects_to_login(self):
        response = self.client.post(reverse("register"), self.registration_data)

        self.assertRedirects(response, reverse("login"))
        user = get_user_model().objects.get(username="alexprinter")
        self.assertTrue(user.check_password("PrintFlow!2026Demo"))
        self.assertNotEqual(user.password, "PrintFlow!2026Demo")

    def test_duplicate_username_displays_validation_error(self):
        get_user_model().objects.create_user(
            username="alexprinter",
            password="Existing!2026Password",
        )

        response = self.client.post(reverse("register"), self.registration_data)

        self.assertEqual(response.status_code, 200)
        self.assertFormError(response.context["form"], "username", "A user with that username already exists.")

    def test_valid_login_redirects_to_home_and_logout_ends_session(self):
        get_user_model().objects.create_user(
            username="alexprinter",
            password="PrintFlow!2026Demo",
        )

        login_response = self.client.post(
            reverse("login"),
            {"username": "alexprinter", "password": "PrintFlow!2026Demo"},
        )
        self.assertRedirects(login_response, reverse("home"))
        self.assertEqual(self.client.get(reverse("home")).status_code, 200)

        logout_response = self.client.post(reverse("logout"))
        self.assertRedirects(logout_response, reverse("home"))
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_invalid_login_stays_on_login_page(self):
        response = self.client.post(
            reverse("login"),
            {"username": "unknown", "password": "incorrect"},
        )

        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.context["form"].non_field_errors())
